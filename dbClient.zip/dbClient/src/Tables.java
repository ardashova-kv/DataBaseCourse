/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author A
 */
public enum Tables {
	FILM, ACTOR, AWARD, LINK_AWARD_FILM, LINK_FILM_ACTOR, LINK_ROLE_AWARD, 
        SESSION,STAGE_DIRECTOR, TICKETS_SOLD
}