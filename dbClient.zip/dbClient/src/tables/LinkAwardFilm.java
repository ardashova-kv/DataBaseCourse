/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tables;

public class LinkAwardFilm  implements java.io.Serializable {


     private Integer id;
     private Integer film;
     private Integer award;

    public LinkAwardFilm() {
    }

    public LinkAwardFilm(Integer film, Integer award) {
       this.film = film;
       this.award = award;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getFilm() {
        return this.film;
    }
    
    public void setFilm(Integer newValue) {
        this.film = newValue;
    }
    
    public Integer getAward() {
        return this.award;
    }
    
    public void setAward(Integer newValue) {
        this.award = newValue;
    }
}
