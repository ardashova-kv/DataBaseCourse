/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tables;


import java.util.Date;

/**
 *
 * @author A
 */
public class Film {
     private Integer id;
     private String name;
     private Short year;
     private String tagline;
     private String description;
     private Integer budget;
     private Date premiere;
     private Integer ageRestrict;
     private Integer mpaa;
     private Integer duration;
     private Integer sequel;
     private Integer prequel;
     private Integer stageDirector;
     private Integer cinemacompany;
     private Float rating;

    public Film() {
    }
    
    public Film(String name, Short year, String tagline, String description, Integer budget, Date premiere, Integer ageRestrict, Integer mpaa, Integer duration, Integer sequel, Integer prequel, Integer stageDirector, Integer cinemacompany, Float rating) {
       this.name = name;
       this.year = year;
       this.tagline = tagline;
       this.description = description;
       this.budget = budget;
       this.premiere = premiere;
       this.ageRestrict = ageRestrict;
       this.mpaa = mpaa;
       this.duration = duration;
       this.sequel = sequel;
       this.prequel = prequel;
       this.stageDirector = stageDirector;
       this.cinemacompany = cinemacompany;
       this.rating = rating;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    
    public void setId(Integer newValue) {
        this.id = newValue;
    }
        
    public String getName() {
        return this.name;
    }
    
    
    public void setName(String newValue) {
        this.name = newValue;
    }
    
    public Short getYear() {
        return this.year;
    }
    
    public void setYear(Short newValue) {
        this.year = newValue;
    }
    
    public String getTagline(){
        return this.tagline;
    }
    
     public void setTagline(String newValue) {
        this.tagline = newValue;
    }
    
     public String getDescription(){
        return this.description;
    }
     
     public void setDescription(String newValue) {
        this.description = newValue;
    }
    
    public Integer getBudget(){
        return this.budget;
    }
    
    public void setBudget(Integer newValue) {
        this.budget = newValue;
    }
    
    public Date getPremiere(){
        return this.premiere;
    }
    
    public void setPremiere(Date newValue) {
        this.premiere = newValue;
    }
    
    public Integer getAgeRestrict(){
        return this.ageRestrict;
    }
    
    public void setAgeRestrict(Integer newValue) {
        this.ageRestrict = newValue;
    }
    
    public Integer getMpaa(){
        return this.mpaa;
    }
    
    public void setMpaa(Integer newValue) {
        this.mpaa = newValue;
    }
    
    public Integer getDuration(){
        return this.duration;
    }
    
    public void setDuration(Integer newValue) {
        this.duration = newValue;
    }
    
    public Integer getSequel(){
        return this.sequel;
    }
    
    public void setSequel(Integer newValue) {
        this.sequel = newValue;
    }
    
    public Integer getPrequel(){
        return this.prequel;
    }
    
    public void setPrequel(Integer newValue) {
        this.prequel = newValue;
    }
    
    public Integer getStageDirector(){
        return this.stageDirector;
    }
    
    public void setStageDirector(Integer newValue) {
        this.stageDirector = newValue;
    }
    
    public Integer getCinemacompany(){
        return this.cinemacompany;
    }
    
    public void setCinemacompany(Integer newValue) {
        this.cinemacompany = newValue;
    }
    
    public Float getRating(){
        return this.rating;
    }
    
    public void setRating(Float newValue) {
        this.rating = newValue;
    }
      
    
    
    /*
    public Integer getTypeOfEvent() {
        return this.typeOfEvent;
    }
    
    public void setTypeOfEvent(Integer typeOfEvent) {
        this.typeOfEvent = typeOfEvent;
    }
    public Date getEvDate() {
        return this.evDate;
    }
    
    public void setEvDate(Date evDate) {
        this.evDate = evDate;
    }
    public String getPlace() {
        return this.place;
    }
    
    public void setPlace(String place) {
        this.place = place;
    }
    public Integer getSeria() {
        return this.seria;
    }
    
    public void setSeria(Integer seria) {
        this.seria = seria;
    }*/
}
