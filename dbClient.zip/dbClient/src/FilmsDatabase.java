
import tables.Sessions;
import tables.StageDirector;
import tables.Actor;
import tables.Award;
import java.util.List;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import tables.Film;

public class FilmsDatabase extends javax.swing.JFrame {

    private boolean isSessionsListLoaded = false;
    
    private boolean isFilmLoaded = false;
    private String currentFilmID = "";
    private Film currentFilm;
    
    /**
     * Creates new form
     */
    public FilmsDatabase() {
        initComponents();
        fillTable(Tables.FILM, "");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TicketsInsert = new javax.swing.JFrame();
        jLabel10 = new javax.swing.JLabel();
        PriceIns = new javax.swing.JTextField();
        jLabel45666 = new javax.swing.JLabel();
        sessionIns = new javax.swing.JComboBox();
        jButton14 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        filmsTable = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        insertTicket = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        name_label = new javax.swing.JLabel();
        actor_label = new javax.swing.JLabel();
        reg_label = new javax.swing.JLabel();
        awards_label = new javax.swing.JLabel();
        tickets_label = new javax.swing.JLabel();
        profit_label = new javax.swing.JLabel();
        rating_label = new javax.swing.JLabel();

        jLabel10.setText("����");

        PriceIns.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PriceInsActionPerformed(evt);
            }
        });

        jLabel45666.setText("�����");

        sessionIns.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "<select item>", "1", "2", "3", "4", "5", "6", "7" }));
        sessionIns.setSelectedItem(null);

        jButton14.setText("��������");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout TicketsInsertLayout = new javax.swing.GroupLayout(TicketsInsert.getContentPane());
        TicketsInsert.getContentPane().setLayout(TicketsInsertLayout);
        TicketsInsertLayout.setHorizontalGroup(
            TicketsInsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TicketsInsertLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TicketsInsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TicketsInsertLayout.createSequentialGroup()
                        .addComponent(jLabel45666)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sessionIns, 0, 403, Short.MAX_VALUE))
                    .addGroup(TicketsInsertLayout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(PriceIns))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TicketsInsertLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton14)))
                .addContainerGap())
        );
        TicketsInsertLayout.setVerticalGroup(
            TicketsInsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TicketsInsertLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TicketsInsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(PriceIns, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(TicketsInsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel45666)
                    .addComponent(sessionIns, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton14)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Films Database");

        filmsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Rating"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Float.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        filmsTable.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        filmsTable.getTableHeader().setReorderingAllowed(false);
        filmsTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                filmsTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(filmsTable);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 602, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 412, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("���-10", jPanel1);

        jPanel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        insertTicket.setText("�������� �����");
        insertTicket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertTicketActionPerformed(evt);
            }
        });

        jLabel13.setText("��������");

        jLabel14.setText("������ �������");

        jLabel15.setText("��������");

        jLabel16.setText("�������");

        jLabel17.setText("�������");

        jLabel18.setText("�����������");

        jLabel19.setText("������� �������");

        name_label.setText("�������� �����");

        actor_label.setText("�������� �����");

        reg_label.setText("�������� �����");

        awards_label.setText("�������� �����");

        tickets_label.setText("�������� �����");

        profit_label.setText("�������� �����");

        rating_label.setText("�������� �����");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(insertTicket)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jLabel14)
                            .addComponent(jLabel15)
                            .addComponent(jLabel16)
                            .addComponent(jLabel17)
                            .addComponent(jLabel18)
                            .addComponent(jLabel19))
                        .addGap(35, 35, 35)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tickets_label)
                            .addComponent(profit_label)
                            .addComponent(rating_label)
                            .addComponent(awards_label)
                            .addComponent(reg_label)
                            .addComponent(actor_label)
                            .addComponent(name_label))))
                .addContainerGap(392, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(name_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(actor_label))
                .addGap(76, 76, 76)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(reg_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(awards_label))
                .addGap(50, 50, 50)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(rating_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(profit_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(tickets_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(insertTicket)
                .addContainerGap(117, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("�����", jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 462, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    
    private void PriceInsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PriceInsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PriceInsActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        TicketsInsert.setVisible(false);
        
        String priceStr=PriceIns.getText();
        if(priceStr.equals("")) return;
        Integer price = Integer.parseInt(priceStr);
        if(price<0) return;
        
        if(sessionIns.getSelectedItem()==null) return;
        String[] t=sessionIns.getSelectedItem().toString().split(" ");       
        
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Query q=session.createSQLQuery("INSERT INTO tickets_sold (PRICE, "+
                    "SESSION1) VALUES (:price, :session1)");
            q.setParameter("price", price);
            q.setParameter("session1", Integer.parseInt(t[0]));
            q.executeUpdate();
        session.getTransaction().commit();
        
        resetTicketsCount();
        
        profit_label.setText(countFilmProfit());
    }//GEN-LAST:event_jButton14ActionPerformed

    
    private void insertTicketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertTicketActionPerformed
        TicketsInsert.setSize(550, 150);
        TicketsInsert.setLocation(this.getLocation());
        TicketsInsert.setVisible(true);

        if(!isSessionsListLoaded){
            loadAndSetSessionsList();
            isSessionsListLoaded = true;
        }
    }//GEN-LAST:event_insertTicketActionPerformed

    private void filmsTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filmsTableMouseClicked
        // ��������� ������� �� ������ �������.
        
        Object o = filmsTable.getValueAt(filmsTable.getSelectedRow(), 0);
        currentFilmID = o.toString();
        List<Film> films = simpleHQL("from Film E where E.id ="+currentFilmID);
        currentFilm = films.get(0);
        isFilmLoaded=true;
        isSessionsListLoaded=false;

        //���������� ������� ������� � �������
        //��������
        name_label.setText(currentFilm.getName());
        //�����
        List<Actor> actorList = simpleHQL("select a.name from Actor a, LinkFilmActor l where l.actor = a.id and l.film="+currentFilmID);
        if (actorList.isEmpty()){
           actor_label.setText("��������. � ���� �� ������� ������");
        }else{
            actor_label.setText(actorList.toString());
        }
        //��������
        List<StageDirector> sd = simpleHQL("from StageDirector s where s.id="+currentFilm.getStageDirector());
        if (sd.isEmpty()){
           reg_label.setText("��������. � ���� �� ������� ������");
        }else{
            reg_label.setText(sd.get(0).getName());
        }
        //�������
        List<Award> awardList = simpleHQL("select a.name from Award a, LinkAwardFilm l where l.award = a.id and l.film="+currentFilmID);
        if (awardList.isEmpty()){
           awards_label.setText("��������. � ���� �� ������� ������");
        }else{
            awards_label.setText(awardList.toString());
        }
        //�������
        try{
            String tmp = currentFilm.getRating().toString();
            rating_label.setText(tmp);
        }catch(NullPointerException e){
            rating_label.setText("��������. � ���� �� ������� ������");
        }
        
        //�����������
        profit_label.setText(countFilmProfit());
        
        resetTicketsCount();
        
        //��� ��������� �� ������� � �������
        jPanel3.setVisible(true);
        jTabbedPane1.setSelectedIndex(1);
     
    }//GEN-LAST:event_filmsTableMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FilmsDatabase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FilmsDatabase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FilmsDatabase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FilmsDatabase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FilmsDatabase().setVisible(true);
               
            }
        });
        
    }
    
    //������ �������
    private void loadAndSetSessionsList(){
        if(!isFilmLoaded) return;
        sessionIns.removeAllItems();
        sessionIns.addItem("<select item>");
        List<Sessions> types = simpleHQL("from Sessions E where E.film ="+currentFilmID);
        for (Sessions o : types) {
            sessionIns.addItem(o.getId()+" ["+o.getDate().toString()+"]");
        }
        sessionIns.setSelectedItem(null);
    }
    //����� �������
    private void resetTicketsCount(){
        if(!isFilmLoaded) return;
        if(currentFilmID.equals("")) return;
        
        String tickets_cnt;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            Query q = session.createQuery("select count(t.id) from TicketsSold t, Sessions s where t.session=s.id and s.film ="+currentFilmID);
            List l = q.list();
            tickets_cnt = l.get(0).toString();
        } catch (HibernateException he) {
            he.printStackTrace();
            return;
        }
        tickets_label.setText(tickets_cnt);
    }
    //�����������
    private String countFilmProfit(){
        if(!isFilmLoaded) return "�������� �����";
        if(currentFilmID.equals("")) return "�������� �����";
        
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            Query q = session.createQuery("select sum(t.price) from TicketsSold t, Sessions s where t.session=s.id and s.film ="+currentFilmID);
            List l = q.list();
            Integer i = Integer.parseInt(l.get(0).toString());
            Integer p = i-currentFilm.getBudget();
            return p.toString();
        } catch (HibernateException he) {
            he.printStackTrace();
            return "��������� ������ ��� �����������";
        }
        
    }
    //������� ���-10
    private void displayFilms(List resultList){
        Vector<String> tableHeaders = new Vector<String>();
        Vector tableData = new Vector();
        tableHeaders.add("ID");
        tableHeaders.add("��������");
        tableHeaders.add("�������");
        int cnt=0;
        for(Object o : resultList) {
            Film film = (Film)o;
            Vector<Object> oneRow = new Vector<Object>();
            oneRow.add(film.getId());
            oneRow.add(film.getName());
            oneRow.add(film.getRating());
            tableData.add(oneRow);
            cnt++;
            if(cnt>9) break;
        }
        filmsTable.setModel(new DefaultTableModel(tableData, tableHeaders));
    }
    
    
    private void fillTable(Tables tType, String query){
        if(query==null)
            query="";
        
        String q="";
        switch(tType){
        case FILM:
                q="from Film f order by f.rating desc";
                break;
        default: 
                q= "from Film";
                break;
        }
        executeHQLSelect(tType, q);
                
    }
    
       
    private List simpleHQL(String hql){
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            Query q = session.createQuery(hql);
            return q.list();
    } catch (HibernateException he) {
        he.printStackTrace();
        return null;
    }
    }
    
    private void executeHQLSelect(Tables tType, String hql) {
       try {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Query q = session.createQuery(hql);
        List resultList = q.list();
        switch(tType){
            case FILM:
                displayFilms(resultList);
                break;
            default: 
                displayFilms(resultList);
                break;
        }
        
        session.getTransaction().commit();
    } catch (HibernateException he) {
        he.printStackTrace();
    }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField PriceIns;
    private javax.swing.JFrame TicketsInsert;
    private javax.swing.JLabel actor_label;
    private javax.swing.JLabel awards_label;
    private javax.swing.JTable filmsTable;
    private javax.swing.JButton insertTicket;
    private javax.swing.JButton jButton14;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel45666;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel name_label;
    private javax.swing.JLabel profit_label;
    private javax.swing.JLabel rating_label;
    private javax.swing.JLabel reg_label;
    private javax.swing.JComboBox sessionIns;
    private javax.swing.JLabel tickets_label;
    // End of variables declaration//GEN-END:variables

    


}
